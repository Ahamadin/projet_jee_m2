package forms;

import java.util.Map;

import dao.UtilisateurDAO;
import gesusers1.Utilisateur;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

public class LoginForm 
{
	public static final String CHAMP_LOGIN = "login";
	public static final String CHAMP_PASSWORD = "password";
	
    private String statusMessage;
    private boolean status;
    private HttpServletRequest request;
    private Utilisateur utilisateur;
    private String login;
    
    public LoginForm(HttpServletRequest request) 
    {
		this.request = request;
		this.status = false;
		this.statusMessage = "Echec de connexion : login et/ou mot de passe incorrecte";
	}
    
    public boolean login() 
    {
		this.login = this.getParameter(CHAMP_LOGIN);
		String password = this.getParameter(CHAMP_PASSWORD);
		
		Utilisateur loggedUser = UtilisateurDAO.get(login);
		
		if (loggedUser != null && loggedUser.getPassword().equals(password)) 
		{
			HttpSession session = request.getSession();
			session.setAttribute("loggedUser", loggedUser);
			
			return true;
		}
		return false;
	}
    
    public void logout() 
    {
    	HttpSession session = request.getSession();
    	session.invalidate();
    }
    
    private String getParameter(String parametre) 
    {
    	String valeur = this.request.getParameter(parametre);
    	
    	if (valeur == null || valeur.isBlank()) {
			
    		return null;
		}
    	
    	return valeur.trim();
    }
    
    public String getStatusMessage() 
    {
		return statusMessage;
	}
    
    public boolean isStatus() 
    {
		return status;
	}
    
    public String getLogin() 
    {
		return login;
	}
}
